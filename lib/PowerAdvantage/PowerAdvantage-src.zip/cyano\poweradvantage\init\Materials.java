package cyano.poweradvantage.init;


public class Materials {

	
	private static boolean initDone = false;
	public static void init(){
		if(initDone) return;
		
		
		initDone = true;
	}
}
