package cyano.basemetals.material;

public interface IMetalObject {

	
	public MetalMaterial getMetalMaterial();
}
